<?php
// router-dist.php

//returning false will cause the server to return it's "normal" response
//for the requested URL.
//If you would like the response to contain something else, return whatever
//content it is you would like the response to contain.
return false;

?>