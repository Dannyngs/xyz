
  
 
 <!-- build:js(app) /_/js/main.js -->
           <script src="https://maps.googleapis.com/maps/api/js"></script>

    <script src="_/scripts/config.js"></script>



 <script src="_/libs/jquery/jquery-2.1.1.min.js"></script>
        <script src="_/libs/scrollmagic/scrollmagic/minified/ScrollMagic.min.js"></script>
        <script src="_/libs/materialize/js/materialize.min.js"></script>
        <script src="_/libs/imagesloaded/imagesloaded.pkgd.js"></script>
        <script src="_/libs/shufflejs/jquery.shuffle.modernizr.min.js"></script>
        <script src="_/libs/masonry/dist/masonry.pkgd.min.js"></script>
        <script src="_/libs/ajaxchimp/jquery.ajaxchimp.min.js"></script>
        <script src="_/libs/isinviewport/isInViewport.min.js"></script>
        <script src="_/scripts/wata.js"></script>
        <script src="_/scripts/starfield.js"></script>






  <!-- endbuild -->

</body>
</html>



