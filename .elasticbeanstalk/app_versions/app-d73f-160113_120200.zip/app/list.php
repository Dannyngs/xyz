

<div id="ajax-status">
    <div class="preloader-wrapper large active">
        <div class="spinner-layer spinner-blue-only actually-green">
            <div class="circle-clipper left">
                <div class="circle"></div>
            </div>
            <div class="gap-patch">
                <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
                <div class="circle"></div>
            </div>
        </div>
    </div>
</div>

<a class="btn-floating btn-large waves-effect waves-dark green accent-2" id="close-ajax">
    <i class="mdi-navigation-close indigo-text text-darken-4"></i>
</a>

<div class="parallax-container" id="hero">
    <div class="parallax"><img src="upload/w3.png" alt="Tape"></div>
</div>

<div class="container">
    <div class="row">
        <div class="col s12 m10 offset-m1">
            <h1>
                1Old fashioned<?php echo $_GET['id']; ?>
            </h1>
            <p class="flow-text grey lighten-4 padding-text">
                Client: Skrillex<br>
                Task: we were asked to record a mixtape with some of the nicest electronic tunes on the market. Years
                1979 and below.
            </p>
            <p class="flow-text">
                His divided, them you&#39;ll God may darkness, which. Deep firmament without called behold which were
                female. Sixth. Shall morning saw gathering bearing brought creepeth green. Fourth itself. Second Itself
                yielding fowl make don&#39;t bearing.
            </p>
            <p class="flow-text">
                Seasons Hath open light creature under blessed every lesser morning shall the blessed give beginning. You.
            </p>
        </div>
    </div>
</div>

<div class="wide-container">
    <iframe width="100%" height="166" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/50713119&amp;color=69f0ae&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
</div>

<div class="container">
    <div class="row">
        <div class="col s12 m10 offset-m1">
            <h3>Tracklist</h3>
            <ol class="flow-text">
                <li>Glamour Manifesto &mdash; Apes on Fire</li>
                <li>Pimenton &mdash; Smoking Eyjafjallajökull</li>
                <li>Fort Minor &mdash; Welcome</li>
                <li>Geskia &mdash; Ghost Coast</li>
                <li>Vök &mdash; Waterfall</li>
                <li>Jamie xx &mdash; Gosh</li>
                <li>Emika &mdash; Battles</li>
                <li>Noisia &mdash; Incessant</li>
                <li>Aphex Twin &mdash; Nanou2</li>
                <li>deadmau5 &mdash; Gula</li>
            </ol>
            <h3>About software</h3>
            <p class="flow-text">
                Bearing face greater i under very creeping gathered whose for lesser make. Form whales creature.
                Without night fruitful give open divided man cattle created lesser face.
            </p>
            <div class="divider"></div>
        </div>
        <div class="col s12 m5 offset-m1">
            <p class="flow-text">
                <a href="#">Listen on SoundCloud <i class="fa fa-soundcloud"></i></a>
            </p>
        </div>
        <div class="col s12 m5">
            <p class="flow-text right-on-med-and-up social">
                Share:
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-google-plus"></i></a>
            </p>
        </div>
    </div>
</div>

