<?php
/*
------------------
Language: Chinese
------------------
*/
 
$lang = array();
 
$lang['treament'] = "治療";
$lang['illness'] = '疾病';
$lang['treament_method'] = '治療方法';
$lang['case'] = '醫案';
$lang['column'] = '專欄';
 $lang['pricing'] = '治療及價目';
 $lang['home'] = '首頁';



 $lang['contact'] = '聯絡我們';
 $lang['address'] = '診所地址';
 $lang['contact_info'] = '聯絡方式';
 $lang['worktime'] = '工作時間';
 $lang['book'] = '立即預約';
 $lang['name'] = '姓名';
 $lang['tel'] = '電話';
 $lang['email'] = '電郵';
 $lang['msg'] = '預約留言';
 $lang['submit'] = '遞交';

?>