<?php
/*
------------------
Language: English
------------------
*/
 
$lang = array();
 
$lang['treament'] = 'Treament';
$lang['illness'] = 'Illness';
$lang['treament_method'] = 'Treament Methods';
$lang['case'] = 'Cases';
$lang['column'] = 'Columns';
  $lang['pricing'] = 'Treament & Pricing';
 $lang['home'] = 'Home';

 $lang['contact'] = 'Contect Us';
 $lang['address'] = 'Address';
 $lang['contact_info'] = 'Contact';
 $lang['worktime'] = 'Working Hours';
 $lang['book'] = 'Make An Appointment Right Now';
 $lang['name'] = 'Name';
 $lang['tel'] = 'Tel';
 $lang['email'] = 'Email';
 $lang['msg'] = 'Message';
 $lang['submit'] = 'Submit';

?>