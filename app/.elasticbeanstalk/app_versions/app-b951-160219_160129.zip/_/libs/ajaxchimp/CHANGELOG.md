# ajaxChimp Changelog

### 1.3.0 - 8/May/2014

- Transalations for success message now work
- Language file: German (updated) - [Cube42](https://github.com/Cube42)

### 1.2.0 - 1/Mar/2014

- Language support for submit message - [lifeisfoo](https://github.com/lifeisfoo)
- Language file: Italian - [lifeisfoo](https://github.com/lifeisfoo)

### 1.1.0 - 15/Dec/2013

- Multiple form support - [tobymarsden](https://github.com/tobymarsden)
- Language Support
- Language file: German, French, Spanish
- Minified files

### 1.0.2 - 06/Aug/2013

- Bower Support
