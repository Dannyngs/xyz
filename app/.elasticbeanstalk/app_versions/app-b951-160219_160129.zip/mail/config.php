<?php
	
$me = array(
    'email' => 'danny.ng@apptisan.xyz',
    'name' => 'danny ng'
);

$smtp = array(
    'enabled' => true,
    'host' => 'msv.c-m.hk',
    'username' => 'danny.ng',
    'password' => 'cmadmin123',
    'port' => 25,
    'tls' => true
);